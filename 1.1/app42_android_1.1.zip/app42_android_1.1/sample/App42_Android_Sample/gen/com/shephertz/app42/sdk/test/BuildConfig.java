/** Automatically generated file. DO NOT MODIFY */
package com.shephertz.app42.sdk.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}